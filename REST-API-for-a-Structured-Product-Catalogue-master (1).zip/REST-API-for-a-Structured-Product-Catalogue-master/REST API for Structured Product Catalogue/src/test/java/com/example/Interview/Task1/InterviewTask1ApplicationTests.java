package com.example.Interview.Task1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewTask1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
