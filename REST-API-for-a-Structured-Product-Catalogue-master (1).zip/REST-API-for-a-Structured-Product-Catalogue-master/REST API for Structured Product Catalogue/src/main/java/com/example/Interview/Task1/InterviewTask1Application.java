package com.example.Interview.Task1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewTask1Application {

	public static void main(String[] args) {
		SpringApplication.run(InterviewTask1Application.class, args);
		System.out.println("Hello Task");
	}

}
